package com.idcarddemo;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.itextpdf.html2pdf.HtmlConverter;

import net.glxn.qrgen.QRCode;
import net.glxn.qrgen.image.ImageType;

@SpringBootApplication
public class IdcarddemoApplication {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(IdcarddemoApplication.class, args);
		//HtmlConverter.convertToPdf(new File("./pdf-input.html"),new File("demo-html.pdf"));
		/*
		 * try { File file = new File("C:\\Users\\msing105\\Desktop\\abc.jpg"); String
		 * content = "this is my content"; ByteArrayOutputStream out =
		 * QRCode.from(content).to(ImageType.JPG).stream(); FileOutputStream fos = new
		 * FileOutputStream(file); fos.write(out.toByteArray()); fos.close();
		 * System.out.println("s"); } catch (Exception e) { e.printStackTrace(); }
		 */
	}

}
