package com.idcarddemo.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.idcarddemo.entity.IdCardEntity;
import com.idcarddemo.idcardservices.IdCardService;
import com.itextpdf.text.DocumentException;

@Controller

public class IdCardController {

	@Autowired
	private IdCardService cardService;
	public static String UPLOAD_DIRECTORY = System.getProperty("user.dir") + "/uploads";

	@PostMapping("")
	public ResponseEntity<IdCardEntity> createUser(@RequestBody IdCardEntity cardInfo) {
		IdCardEntity user1 = cardService.saveCardInfo(cardInfo);
		return ResponseEntity.status(HttpStatus.CREATED).body(user1);
	}

	@GetMapping("/hello")
	public String hello(Model model) {
		model.addAttribute("names", cardService.getAllUser());
		return "hello.html";
	}

	@GetMapping("/employee/new")
	public String hello1(Model model) {
		IdCardEntity cardObject = new IdCardEntity();

		model.addAttribute("cardinfo", cardObject);
		return "create.html";
	}

	@GetMapping("/employee/add")
	public String employee(Model model) {
		IdCardEntity cardObject = new IdCardEntity();

		model.addAttribute("cardinfo", cardObject);
		return "addProduct.html";
	}

	@PostMapping("/hello")
	public String saveEmployee(@ModelAttribute("cardEntity") IdCardEntity cardEntity) {
		IdCardEntity cardInfo = cardService.saveCardInfo(cardEntity);

		return "redirect:hello";
	}

	@GetMapping("/display")
	public String displaForm(Model model) {
		model.addAttribute("names", cardService.getAllUser());
		return "addProduct.html";
	}

	@PostMapping("/list")
	public String saveProduct(@RequestParam("file") MultipartFile file, @RequestParam("pname") String name,
			@RequestParam("designation") String designation, @RequestParam("bloodGroup") String bloodGroup,
			@RequestParam("age") int age) {

		cardService.saveProductToDB(file, name, designation, bloodGroup, age);
		return "redirect:list";
	}

	@GetMapping("/list")
	public String listproduct(Model model) {
		model.addAttribute("names", cardService.getAllUser());
		return "listproduct.html";
	}

	@GetMapping("/employee/edit/{id}")
	public String editEmployeeForm(@PathVariable String id, Model model) {

		model.addAttribute("employee", cardService.getUser(id));
		return "edit_employee.html";
	}

	@PostMapping("/employee/{id}")
	public String updateEmployee(@PathVariable String id, @ModelAttribute("cardEntity") IdCardEntity cardEntity,
			Model model) {
		IdCardEntity existingEmployee = cardService.getUser(id);
		existingEmployee.setAge(cardEntity.getAge());
		existingEmployee.setBloodGroup(cardEntity.getBloodGroup());
		existingEmployee.setDate(cardEntity.getDate());
		existingEmployee.setDesignation(cardEntity.getDesignation());
		existingEmployee.setName(cardEntity.getName());
		existingEmployee.setIdCardNumber(id);
		cardService.updateUser(existingEmployee);

		return "redirect:/list";

	}

	@GetMapping("/employee/{id}")
	public String deleteEmployee(@PathVariable String id) {
		cardService.deleteById(id);
		return "redirect:/list";
	}

	@GetMapping("/employee/getdetails/{id}")
	public String getEmployeeDetails(@PathVariable String id, Model model) {

		IdCardEntity existingEmployee = cardService.getUser(id);
		model.addAttribute("employee", cardService.getUser(id));
		return "get_detail.html";
	}

	@GetMapping("/export-to-pdf/{id}")
	public void generatePdfFile(HttpServletResponse response, @PathVariable String id)
			throws DocumentException, IOException {
		response.setContentType("application/pdf");
		DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-DD");
		String currentDateTime = dateFormat.format(new Date(0));
		String headerkey = "Content-Disposition";
		IdCardEntity listofStudents = cardService.getUser(id);
		String headervalue = "attachment; filename=" + listofStudents.getName() + currentDateTime + ".pdf";
		response.setHeader(headerkey, headervalue);

		PdfGenerator generator = new PdfGenerator();
		generator.generate(listofStudents, response);
	}

	@GetMapping("/uploadimage")
	public String displayUploadForm(Model model) {
		model.addAttribute("names", cardService.getAllUser());
		return "index.html";
	}

	@PostMapping("/upload")
	public String uploadImage(Model model, @RequestParam("filePath") MultipartFile file)
			throws IOException {
		StringBuilder fileNames = new StringBuilder();
		Path fileNameAndPath = Paths.get(UPLOAD_DIRECTORY, file.getOriginalFilename());
		fileNames.append(file.getOriginalFilename());
		Files.write(fileNameAndPath, file.getBytes());
		model.addAttribute("msg", "Uploaded images: " + fileNames.toString());
		IdCardEntity cardInfo = new IdCardEntity();

		cardInfo.setFilePath(file.getOriginalFilename());
		model.addAttribute("employee", cardInfo);
		cardService.saveCardInfo(cardInfo);
		return "index.html";
	}

}
