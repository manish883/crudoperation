package com.idcarddemo.entity;



import java.sql.Date;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="IdCardEntity")
public class IdCardEntity {

	@Id
	@Column(name="idCardNumber")
	private String idCardNumber;
	@Column(name="name")
	private String name;
	@Column(name="age")
	private int age;
	@Column(name="bloodGroup")
	private String bloodGroup;
	@Column(name="designation")
	private String designation;
	@Column(name = "date")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date date;
	@Lob
	@Column(columnDefinition = "MEDIUMBLOB")
	private String filePath;
	@Lob
	@Column(columnDefinition = "MEDIUMBLOB")
	private String qrCode;
	
}
