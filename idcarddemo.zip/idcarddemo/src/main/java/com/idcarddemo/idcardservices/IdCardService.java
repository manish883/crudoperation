package com.idcarddemo.idcardservices;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.idcarddemo.entity.IdCardEntity;


public interface IdCardService {

	IdCardEntity saveCardInfo(IdCardEntity cardInfo);
	IdCardEntity getUser(String userId);

	void saveProductToDB(MultipartFile file, String name, String Description,String bloodGroup,int age );
	List<IdCardEntity> getAllUser();
	IdCardEntity updateUser(IdCardEntity cardInfo);
	void deleteById(String userId);
	
}
