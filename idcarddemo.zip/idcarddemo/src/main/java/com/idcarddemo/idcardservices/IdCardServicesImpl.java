package com.idcarddemo.idcardservices;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.idcarddemo.entity.IdCardEntity;
import com.idcarddemo.repository.IdCardRepo;
import com.itextpdf.io.image.ImageData;

import net.glxn.qrgen.QRCode;
import net.glxn.qrgen.image.ImageType;

@Service
public class IdCardServicesImpl implements IdCardService {

	@Autowired
	private IdCardRepo cardRepo;
	private final String FOLDER_PATH = "C:\\Users\\msing105";

	@Override
	public IdCardEntity saveCardInfo(IdCardEntity cardInfo) {
		AtomicLong idCounter = new AtomicLong(100);
		long timestamp = System.currentTimeMillis();
		long nextLong = idCounter.incrementAndGet();
		String randomId = String.valueOf(timestamp) + String.valueOf(nextLong);
		cardInfo.setIdCardNumber(randomId);
		String pattern = "dd/MM/yyyy";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

		return cardRepo.save(cardInfo);
	}

	@Override
	public IdCardEntity getUser(String userId) {
		// TODO Auto-generated method stub
		IdCardEntity cardInfo = cardRepo.findById(userId).orElseThrow();
		
		ByteArrayOutputStream out = QRCode.from(cardInfo.getName() + cardInfo.getDesignation())
				.to(ImageType.PNG).stream();
		cardInfo.setQrCode(Base64.getEncoder().encodeToString(out.toByteArray()));
		return cardInfo;
	}

	@Override
	public void deleteById(String userId) {

		cardRepo.deleteById(userId);

	}

	@Override
	public List<IdCardEntity> getAllUser() {
		// TODO Auto-generated method stub
		return cardRepo.findAll();
	}

	@Override
	public IdCardEntity updateUser(IdCardEntity cardInfo) {

		return cardRepo.save(cardInfo);
	}

	@Override
	public void saveProductToDB(MultipartFile file, String name, String designation,String bloodGroup , int age ) {

		IdCardEntity cardInfo = new IdCardEntity();
		StringBuilder fileNames = new StringBuilder();
		fileNames.append(file.getOriginalFilename());
		AtomicLong idCounter = new AtomicLong(100);
		long timestamp = System.currentTimeMillis();
		long nextLong = idCounter.incrementAndGet();
		String randomId = String.valueOf(timestamp) + String.valueOf(nextLong);
		cardInfo.setIdCardNumber(randomId);
		cardInfo.setName(name);
		cardInfo.setBloodGroup(bloodGroup);
		cardInfo.setAge(age);
		cardInfo.setDesignation(designation);
		ByteArrayOutputStream out = QRCode.from(cardInfo.getName() + cardInfo.getDesignation())
				.to(ImageType.PNG).stream();
		
		cardInfo.setQrCode(Base64.getEncoder().encodeToString(out.toByteArray()));
		try {
			cardInfo.setFilePath(Base64.getEncoder().encodeToString(file.getBytes()));
		} catch (IOException e) {
			
			e.printStackTrace();
			
		}
		cardRepo.save(cardInfo);
		// return null;
	}

}
