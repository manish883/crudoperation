package com.idcarddemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.idcarddemo.entity.IdCardEntity;
@Repository
public interface IdCardRepo extends JpaRepository<IdCardEntity, String>{

}
